from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import *
ready=0;
user1=""
# Create your views here.
def index(request):
   return render(request, 'chessGame/index.html')


def main(request):
   #str=request.POST['title']
   str = request.POST.get('title', False)
   room = RoomInfo.objects.all()
   #user=UserInfo(name=request.POST['title'])
   #user.save
   UserInfo.objects.create(name=str)
   user = UserInfo.objects.get(name=str)
   request.session['user_id']=request.POST['title']   
   user.one_or_two = 2
   user.save()
   context={'rooms':room }
   return render(request, 'chessGame/main.html', context)
   #return HttpResponse(k.name)

def make(request):
   return render(request, 'chessGame/make.html')
   #return HttpResponse("방만들기")

def ing(request):
   user = UserInfo.objects.get(name=request.session['user_id'])
   user.one_or_two = 1
   str = request.POST.get('roomname', False)
   RoomInfo.objects.create(name=str)
   room = RoomInfo.objects.get(name=str)
   room.user1 = user.name
   room.save()

   context = {'roominform' : room , 'room_no' : room.id }

  # return render (request, 'chessGame/room.html' , context)
   return HttpResponseRedirect("/room/{}/".format(room.id))

def room(request, room_id):
	user = UserInfo.objects.get(name=request.session['user_id'])
	room = RoomInfo.objects.get(id=int(room_id))
	if(room.full == 0):
		room.user1=user.name
		room.full = 1
		room.save()
		context={'room': room}
		return render(request, 'chessGame/room.html',context)
	elif(room.full == 1):
		room.user2 = user.name
		room.full = 2 
		room.save()
		context={'room' : room }
		return render(request, 'chessGame/room.html',context)

	room = RoomInfo.objects.all()
	context={'rooms':room }
	return render(request, 'chessGame/main.html', context)

	#return HttpResponse("방 안")
def chess(request, room_id):
	global ready
	ready +=1
	user = UserInfo.objects.get(name=request.session['user_id'])
	room = RoomInfo.objects.get(id=int(room_id))
	while(ready < 2):
		pass
	"""
	a=검은 폰
	b=검은 룩
	c=검은 나이트
	d=검은 비숍
	e=검은 퀸
	f=검은 킹

	g=하얀 폰
	h=하얀 룩
	i=하얀 나이트
	j=하얀 비숍
	k=하얀 퀸
	l=하얀 킹

	x=빈칸
	"""
	board=[['b','c','d','e','f','d','c','b'],
			['a','a','a','a','a','a','a','a'],
			['x','x','x','x','x','x','x','x'],
			['x','x','x','x','x','x','x','x'],
			['x','x','x','x','x','x','x','x'],
			['x','x','x','x','x','x','x','x'],
			['g','g','g','g','g','g','g','g'],
			['h','i','j','k','l','j','i','h']]

	chess=ChessBoard.objects.filter(room_number=room_id)

	if(chess):
		#str=request.POST.get('move', False)
		ptr=chess[0].board
		a=0
		a=int(a)
		for i in range(0,8):
			for u in range(0,8):
				board[i][u]=ptr[a]
				a+=1

		context={'board':board,'str':str,'room':room,'user':user}
		#return HttpResponse(ptr)	
		return render(request, 'chessGame/chess.html',context)

	else:
		b=""
		for i in board:
			for j in i:
				b=b+j
		ChessBoard.objects.create(board=b, room_number=room_id)
		context={'board':board,'room':room,'user':user}
		#return HttpResponse(b)
		return render(request, 'chessGame/chess.html',context)

def chess_ing(request, room_id):
	global ready
	ready+=1
	str=request.POST.get('move', False)
	#str예외처리 필요

	board=[['b','c','d','e','f','d','c','b'],
			['a','a','a','a','a','a','a','a'],
			['x','x','x','x','x','x','x','x'],
			['x','x','x','x','x','x','x','x'],
			['x','x','x','x','x','x','x','x'],
			['x','x','x','x','x','x','x','x'],
			['g','g','g','g','g','g','g','g'],
			['h','i','j','k','l','j','i','h']]

	chess=ChessBoard.objects.get(room_number=room_id)
	ptr=chess.board

	a=0
	#a=int(a)
	for i in range(0,8):
		for u in range(0,8):
			board[i][u]=ptr[a]
			a+=1

	piece=board[int(str[0])][int(str[1])]
	#piece와 str을 인자로 받아 piece의 str동작이 올바른 동작인지 판별하는 함수 필요
	#동작이 적절하면 아래 실행
		
	board[int(str[2])][int(str[3])]=board[int(str[0])][int(str[1])]
	board[int(str[0])][int(str[1])]='x'

	b=""
	for i in board:
		for j in i:
			b=b+j

	chess.board=b
	chess.save()

	#context={'board':board,'str':str}
	#return HttpResponse(chess.board)	
	#return render(request, 'chessGame/chess.html',context)
	return HttpResponseRedirect("/room/{}/chess".format(room_id))

