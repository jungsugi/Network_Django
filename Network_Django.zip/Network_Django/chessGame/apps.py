from django.apps import AppConfig


class ChessgameConfig(AppConfig):
    name = 'chessGame'
